package fuzs.forgeconfigapiport.fabric.impl.client.core;

import fuzs.forgeconfigapiport.fabric.api.neoforge.v4.client.ConfigScreenFactoryRegistry;
import java.util.HashMap;
import java.util.Map;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.UnaryOperator;
import java.util.stream.Collectors;
import net.minecraft.client.gui.screens.Screen;

public final class ConfigScreenFactoryRegistryImpl implements ConfigScreenFactoryRegistry {
    private final Map<String, UnaryOperator<Screen>> factories = new HashMap<>();

    @Override
    public void register(String modId, BiFunction<String, Screen, Screen> factory) {
        this.factories.put(modId, (Screen screen) -> factory.apply(modId, screen));
    }

    public <T> Map<String, T> getConfigScreenFactories(Function<UnaryOperator<Screen>, T> converter) {
        return this.factories.entrySet()
                .stream()
                .collect(Collectors.toMap(Map.Entry::getKey, (Map.Entry<String, UnaryOperator<Screen>> entry) -> {
                    return converter.apply(entry.getValue());
                }));
    }
}
